# AI Reference Generation Guide For Bedrock Blockbench Models

This document defines how to write prompts for AI-generated reference sheets before creating a Minecraft Bedrock model in Blockbench. It is general-purpose and must not be tied to one asset type.

Use this guide to generate references for:

- characters,
- mobs,
- creatures,
- vehicles,
- weapons,
- tools,
- furniture,
- machines,
- decorative props,
- blocks,
- environment pieces,
- UI-like display props.

## Core Goal

The reference must help modelling decisions, not just look impressive.

Good reference output should answer:

- What is the front?
- What is the silhouette?
- What is geometry?
- What is texture?
- What is the scale?
- What are the focal details?
- What materials and colors are used?
- What should be avoided?

## Critical Prompt Rule

Do not ask for a generic voxelized image.

Use:

```text
Minecraft Bedrock / Blockbench production reference sheet.
Cube-based model with varied cuboid proportions, layered shapes, angled plates where useful, clean silhouette, and pixel-art texture guidance.
```

Avoid:

```text
Voxelized, cube-only, blocky everywhere, generic voxel art, random pixel sculpture, smooth 3D render, realistic PBR render.
```

Reason:

- "Voxelized" often produces noisy square patterns instead of useful Blockbench geometry.
- Minecraft style is cube-based, but not every design detail should become a cube.
- Good Blockbench references show which shapes are physical geometry and which details are texture.

## Required Reference Package

Generate references in this order:

```text
01_[asset]_orthographic_views.png
02_[asset]_scale_sheet.png
03_[asset]_silhouette_sheet.png
04_[asset]_part_breakdown_sheet.png
05_[asset]_color_palette_sheet.png
06_[asset]_texture_reference_[atlas_size].png
07_[asset]_closeup_detail_sheet.png
08_[asset]_do_dont_sheet.png
09_[asset]_animation_pivot_sheet_optional.png
```

Do not skip the Orthographic View Sheet, Scale Sheet, or Part Breakdown Sheet. Those are the minimum for modelling.

Reference authority order:

```text
1. Orthographic views: front, side, back, top, proportions.
2. Scale sheet: dimensions, contact points, comparison target.
3. Silhouette sheet: distance readability and identity.
4. Part breakdown sheet: geometry groups and texture-only detail.
5. Close-up detail sheet: focal areas and local detail placement.
6. Color palette sheet: material colors.
7. Texture reference sheet: gradients, shading, and material depth.
8. Do / Don't sheet: mistakes to avoid.
9. Animation pivot sheet: pivots and motion only when relevant.
```

If two sheets conflict, the higher-priority sheet wins and the conflict is marked `Needs verification`.

## Layout Preview Examples

The following local images are layout examples only. They show the kind of reference-sheet structure that is useful for AI-assisted Blockbench modelling.

Do not copy the shown asset, theme, proportions, colors, or exact design unless the current asset brief explicitly asks for it.

Use these examples only for:

- panel organization,
- labels,
- view separation,
- scale callouts,
- part breakdown layout,
- palette layout,
- close-up layout,
- texture explanation layout,
- do / don't comparison layout.

Layout preview files:

- Orthographic view layout: `C:\Users\Administrator\Downloads\140fec2f-e794-480d-9ed1-c40105bc131d.png`
- Scale sheet layout: `C:\Users\Administrator\Downloads\b66ab85f-8fe8-4b50-b624-f842ac95d546.png`
- Color palette layout: `C:\Users\Administrator\Downloads\dbbfcb58-0db1-4239-bbd3-b18174520f5b.png`
- Texture reference layout: `C:\Users\Administrator\Downloads\43cc7710-3a9f-4a7d-876d-98dc7d8c5888.png`
- Part breakdown layout: `C:\Users\Administrator\Downloads\95577a49-9599-44c9-bbd9-ac6546089ae4.png`
- Close-up detail layout: `C:\Users\Administrator\Downloads\ed1d88c5-f4d2-442d-b44a-edee942bafbf.png`
- Do / don't layout: `C:\Users\Administrator\Downloads\81643f12-6bbb-4c6e-b299-d1df512670f8.png`

When using these as prompt context, say:

```text
Use the attached image only as a layout/composition reference.
Do not copy the asset, theme, character, colors, or exact model.
Generate a new reference sheet for the asset described in this prompt.
```

## Global Style Instructions

Add these instructions to every reference-generation prompt:

```text
Style:
Minecraft Bedrock / Blockbench production reference.
Cube-based construction using cuboids, not noisy voxelization.
Use varied rectangular cuboid sizes, clean stepped shapes, layered parts, and readable silhouettes.
Keep shapes practical for Blockbench modelling.
Show details as either geometry-level forms or texture-level pixel details.
Avoid smooth organic sculpting, realistic rendering, excessive tiny cubes, random voxel noise, and overly flat cube-only bodies.
Use crisp pixel-art material shading with 3 to 5 stepped values per material.
Use a clean white or light neutral reference-sheet background.
Use clear labels and simple guide lines.
```

## Global Negative Prompt

Use this negative prompt for every sheet:

```text
Avoid: generic voxelized statue, random tiny cubes, noisy mosaic texture, smooth realistic 3D render, high-poly sculpt, rounded organic surfaces, blurry details, unreadable labels, inconsistent front/back design, inconsistent scale between views, excessive ornaments that cannot be built in Blockbench, floating parts without support, duplicate conflicting designs, flat single-color surfaces, over-saturated colors.
```

## Phase 1 Reference: Orthographic View Sheet

Purpose: lock the model direction and front/back orientation.

Prompt template:

```text
Create an orthographic reference sheet for a Minecraft Bedrock / Blockbench model.

Asset:
[asset name and short description]

Function:
[in-game function]

Views required:
- Front view
- Left side view
- Back view
- Top view if important
- 3/4 view thumbnail

Style requirements:
- Cube-based Blockbench-friendly construction.
- Use varied cuboid proportions, not uniform cube-only voxelization.
- Keep the silhouette clear from all views.
- Show major geometry as physical cuboid forms.
- Show small trims, seams, color bands, scratches, and gradients as texture-level details.
- Keep all views consistent in proportions and design.
- Mark the front clearly.

Labels:
- FRONT
- SIDE
- BACK
- TOP if included
- Main silhouette parts
- Main focal area
- Primary attachments or props

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- Which side is front?
- What are the large silhouette parts?
- Are all views consistent?
- What parts must be physically modelled?
- What parts should be texture-only?

Accept if:

- Front, side, and back agree.
- The silhouette is readable.
- It does not look like random voxel noise.

Reject if:

- The views conflict.
- It is too smooth or too realistic.
- It is just a uniform voxelized statue.
- Important parts float without logic.

## Phase 2 Reference: Scale Sheet

Purpose: define proportions before geometry.

Prompt template:

```text
Create a scale sheet for a Minecraft Bedrock / Blockbench model.

Asset:
[asset name]

Scale target:
[small / medium / large]

Compared to:
[item / block / player / mob / vehicle / other]

Required scale notes:
- Total height, width, and depth in Blockbench units or pixels.
- Major part proportions.
- Focal area size.
- Attachment or prop size.
- Ground/base/contact point.

Style requirements:
- Blockbench-friendly cuboid proportions.
- Use clear measurement arrows.
- Keep proportions consistent with the orthographic sheet.
- Include a Minecraft block or player-scale comparison if relevant.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What is the total height?
- What is the total width?
- What is the total depth?
- What is the size of the focal area?
- What is the scale comparison target?

Accept if:

- Measurements are readable.
- Scale matches the intended category.
- Contact points are clear.

Reject if:

- The scale sheet invents a different design.
- Measurements are unreadable.
- The model has no clear ground/base/contact logic.

## Phase 3 Reference: Silhouette Sheet

Purpose: verify readability before cube detailing.

Prompt template:

```text
Create a silhouette readability sheet for a Minecraft Bedrock / Blockbench model.

Asset:
[asset name]

Show:
- Front silhouette
- Side silhouette
- Back silhouette
- 3/4 silhouette
- Small-size readability test

Style requirements:
- Black silhouette on light background.
- Clear readable large shapes.
- No cluttered random protrusions.
- Show which features make the asset recognizable.
- Keep the silhouette compact enough for Minecraft gameplay.

Label:
- Top silhouette features
- Side-profile features
- Base/contact shape
- Focal identity shape

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What makes the asset recognizable from far away?
- Which 3 to 5 silhouette features are essential?
- Which protrusions are optional?
- Is the silhouette too messy?

Accept if:

- The model is identifiable at small size.
- Essential features are readable.
- The outline is not cluttered.

Reject if:

- The silhouette depends on texture only.
- The outline is messy.
- The model reads as a generic block.

## Phase 4 Reference: Part Breakdown Sheet

Purpose: separate geometry-level parts from texture-level details.

Prompt template:

```text
Create a Blockbench part breakdown sheet for a Minecraft Bedrock model.

Asset:
[asset name]

Break down the model into:
- Primary body or main structure
- Secondary supports or limbs
- Attachments or props
- Focal identity area
- Base/contact parts
- Optional animated parts if any

For each part, show:
- Front view
- Side view if needed
- Back or top view if needed
- Geometry note
- Texture note

Important:
- Clearly mark GEOMETRY parts.
- Clearly mark TEXTURE-ONLY details.
- Avoid turning every small stripe or color panel into a separate cube.
- Use fewer larger cuboids for structure, and texture for small surface detail.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What are the major geometry groups?
- Which details are texture-only?
- Which parts may share symmetry?
- Which parts may need animation pivots?
- Which parts must attach to the body/base?

Accept if:

- Parts are buildable in Blockbench.
- Geometry and texture roles are separated.
- It discourages unnecessary cube detail.

Reject if:

- Every small mark becomes a cube.
- Parts float without attachment logic.
- The sheet is visually nice but not buildable.

## Phase 5 Reference: Color Palette Sheet

Purpose: define material identity before texture work.

Prompt template:

```text
Create a color palette sheet for a Minecraft Bedrock / Blockbench model.

Asset:
[asset name]

Palette requirements:
- 6 to 10 total colors.
- Primary material color.
- Secondary material color.
- Shadow color.
- Mid-tone color.
- Highlight color.
- Accent color.
- Optional metal, wood, stone, glass, cloth, glow, or organic material colors.

For each color:
- Color name
- Hex value
- Material use
- Where it appears on the model

Style requirements:
- Pixel-art friendly colors.
- Avoid overly saturated colors unless intentional.
- Avoid pure black except deepest shadow.
- Include 3 to 5 value steps for important materials.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What is the dominant color?
- What is the darkest usable shadow?
- What is the highlight color?
- What accent colors are allowed?
- Which materials use which colors?

Accept if:

- Palette is limited and readable.
- Colors support pixel-art shading.
- Material use is clear.

Reject if:

- Palette has too many colors.
- Colors are random or over-saturated.
- No material placement is explained.

## Phase 6 Reference: Texture Reference Sheet

Purpose: guide UV painting and material gradients.

Prompt template:

```text
Create a Minecraft Bedrock texture reference sheet for a Blockbench model.

Asset:
[asset name]

Show texture guidance for:
- Primary material
- Secondary material
- Dark/recessed material
- Accent material
- Metal/wood/stone/fabric/glass/glow/organic material if relevant
- Focal identity detail
- Edge highlights
- Ambient shadow under overlaps
- Subtle wear or surface variation

Style requirements:
- Pixel-art stepped shading.
- 3 to 5 values per important material.
- Show dark edge, mid tone, brighter edge, and small highlight.
- Show how gradients appear on cuboid faces.
- Show texture-only details such as seams, stripes, panel lines, scratches, trims, and small shadows.
- Keep examples usable on a 64x64, 128x128, or 256x256 atlas.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- How should each material be shaded?
- Where do highlights go?
- Where do shadows go?
- Which details are texture-only?
- Which large faces must not remain flat?

Accept if:

- It shows usable stepped gradients.
- It separates material types.
- It avoids one-color flat panels.

Reject if:

- It is only a color palette.
- It uses smooth blur instead of pixel steps.
- It does not explain where textures appear.

## Phase 7 Reference: Close-Up Detail Sheet

Purpose: clarify focal details before final modelling or texturing.

Prompt template:

```text
Create a close-up detail sheet for the focal areas of a Minecraft Bedrock / Blockbench model.

Asset:
[asset name]

Focal areas:
[list 3 to 5 focal areas]

For each focal area, show:
- Close-up image
- Geometry-level shape
- Texture-level detail
- Attachment or alignment note
- What must remain readable from the normal front or gameplay view

Style requirements:
- Blockbench-friendly cuboid construction.
- Avoid tiny unbuildable geometry.
- Use texture for small details.
- Make focal identity readable.
- Keep front/back orientation clear.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What are the focal areas?
- Which focal details are geometry?
- Which focal details are texture?
- What must be readable from normal view?
- Which side is the visible/intended side?

Accept if:

- Focal details are clear.
- Geometry and texture roles are separated.
- Orientation is obvious.

Reject if:

- Focal details only work from one decorative angle.
- The sheet adds random extra design.
- Front-only details appear on the wrong side.

## Phase 8 Reference: Do / Don't Sheet

Purpose: prevent repeated mistakes during modelling.

Prompt template:

```text
Create a Do / Don't reference sheet for a Minecraft Bedrock / Blockbench model.

Asset:
[asset name]

Show:
- Correct silhouette examples.
- Incorrect silhouette examples.
- Correct geometry layering.
- Incorrect floating or disconnected parts.
- Correct texture gradient.
- Incorrect flat single-color texture.
- Correct cube efficiency.
- Incorrect excessive tiny cubes.
- Correct Minecraft Bedrock style.
- Incorrect generic voxelized style.

Style requirements:
- Left column: DO.
- Right column: DON'T.
- Use clear labels.
- Keep examples directly relevant to the asset.
- Make mistakes easy to identify.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- What should the model definitely do?
- What should the model avoid?
- What counts as too many cubes?
- What counts as too flat?
- What counts as wrong style?

Accept if:

- It gives practical checks.
- It prevents obvious modelling mistakes.
- It is specific to the asset while still Blockbench-friendly.

Reject if:

- The don't examples are vague.
- It does not cover geometry and texture.
- It only compares finished artwork.

## Optional Reference: Animation Pose Sheet

Use only for Bedrock Entity when animation is required.

Prompt template:

```text
Create an animation pose reference sheet for a Minecraft Bedrock Entity model.

Asset:
[asset name]

Required animations:
- idle
- walk or movement
- attack or action
- custom if needed

Show:
- Neutral pose
- Key pose 1
- Key pose 2
- Key pose 3
- Moving parts
- Pivot hints
- Parts that should stay rigid

Style requirements:
- Blockbench-friendly bone and cube movement.
- Avoid complex deformation.
- Keep motion readable with simple rotations and offsets.
- Preserve Minecraft-style stiffness while avoiding robotic motion.

Negative prompt:
[paste Global Negative Prompt]
```

Minimum required answers:

- Which parts move?
- Which parts stay rigid?
- Where are the pivots?
- What is the animation mood?
- Is the animation looped?

Accept if:

- It can be translated to simple Blockbench animation.
- It identifies moving parts.
- It does not require mesh deformation.

Reject if:

- It depends on smooth bending.
- It has unclear pivots.
- It changes the model design.

## Master Prompt Template

Use this template before asking ChatGPT to generate any reference sheet:

```text
I need a Minecraft Bedrock / Blockbench production reference sheet.

Asset:
[asset name]

Asset type:
[character / mob / creature / vehicle / block / prop / weapon / tool / furniture / machine / environment piece / other]

In-game function:
[what it does in game]

Target category:
[Bedrock Entity / Bedrock Block]

Target quality:
Marketplace-style Minecraft Bedrock model reference.

Important style direction:
- Cube-based Blockbench-friendly construction.
- Use varied cuboid proportions, layered shapes, and clean silhouette.
- Do not make it a generic noisy voxelized object.
- Do not force every small detail into geometry.
- Separate geometry-level forms from texture-level details.
- Use pixel-art material shading with stepped gradients.
- Keep the model readable from front, side, back, and 3/4 view.

Reference sheet requested:
[Orthographic View / Scale / Silhouette / Part Breakdown / Color Palette / Texture Reference / Close-Up Detail / Do-Don't / Animation Pose]

Must include:
[sheet-specific requirements]

Must answer:
[sheet-specific minimum questions]

Avoid:
generic voxelized statue, random tiny cubes, noisy mosaic texture, smooth realistic 3D render, high-poly sculpt, rounded organic surfaces, blurry details, unreadable labels, inconsistent front/back design, inconsistent scale between views, excessive tiny cubes, floating parts without support, flat single-color surfaces, over-saturated colors.
```

## Minimum Reference Checklist Before Modelling

Do not start MCP modelling unless these are answered:

- Asset name.
- Asset type.
- Bedrock Entity or Bedrock Block.
- In-game function.
- Scale target.
- Front orientation.
- Main silhouette features.
- Major geometry parts.
- Texture-only details.
- Focal areas.
- Material palette.
- Do / don't rules.

If any item is missing, stop and ask for that item only.

## Acceptance Criteria

- The guide is general-purpose.
- It does not require a specific model shape.
- It helps generate references that are useful for Blockbench modelling.
- It reduces voxelization hallucination.
- It separates geometry, texture, scale, and focal details.
- It provides phase-specific prompt templates.
- It defines minimum answers required before modelling can continue.
