# CODEX_REFERENCE_HANDOFF

Use this after all reference sheets and `.notes.md` files are complete.

This is the single agent-readable summary for Codex. It does not replace the per-sheet notes; it points Codex to the exact source files and resolves the most important interpretation rules.

## Asset Summary

- Asset name:
- Target category: Bedrock Entity
- In-game function:
- Style/theme:
- Scale target:
- Animation-ready later:
- Selected Blockbench sample calibration:

## Files Included

| Order | Image | Notes | Purpose | Status |
| --- | --- | --- | --- | --- |
| 01 | 01_[asset]_orthographic_views.png | 01_[asset]_orthographic_views.notes.md | Orthographic form reference | required |
| 02 | 02_[asset]_scale_sheet.png | 02_[asset]_scale_sheet.notes.md | Scale and envelope reference | required |
| 03 | 03_[asset]_silhouette_sheet.png | 03_[asset]_silhouette_sheet.notes.md | Readability reference | required |
| 04 | 04_[asset]_part_breakdown_sheet.png | 04_[asset]_part_breakdown_sheet.notes.md | Geometry blueprint reference | required |
| 05 | 05_[asset]_color_palette_sheet.png | 05_[asset]_color_palette_sheet.notes.md | Color/material reference | required |
| 06 | 06_[asset]_texture_reference_[atlas_size].png | 06_[asset]_texture_reference_[atlas_size].notes.md | Texture guidance | required |
| 07 | 07_[asset]_closeup_detail_sheet.png | 07_[asset]_closeup_detail_sheet.notes.md | Focal detail reference | required |
| 08 | 08_[asset]_do_dont_sheet.png | 08_[asset]_do_dont_sheet.notes.md | Failure prevention | required |
| 09 | 09_[asset]_animation_pivot_sheet_optional.png | 09_[asset]_animation_pivot_sheet_optional.notes.md | Pivot readiness | optional/required if animation-ready |

## View Priority

- Primary dimension sources:
- Secondary layout sources:
- Visual preview only:
- Do not use as measurement source:

## Geometry Blueprint Summary

| Part | Role | Approx size | Position from root | Attachment | Rotation/pivot | Build phase |
| --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |  |

## Geometry-Level Features

Build these as geometry:

- 

## Texture-Only Features

Do not build these as cubes:

- 

## Confirmed Decisions

- Front direction:
- Global envelope:
- Contact/hover reference:
- Part build order:
- Complexity target:
- Texture size:

## Needs Verification

- 

## Do Not Misinterpret

- 

## Codex First Action

```text
Run Reference Collection only. Read this handoff, reference_manifest.json, and all per-sheet .notes.md files. Do not edit Blockbench until the Geometry Blueprint is accepted.
```
