# Reference Sheet Notes Template

Use one notes file per reference image.

Filename pattern:

```text
01_[asset]_orthographic_views.notes.md
02_[asset]_scale_sheet.notes.md
03_[asset]_silhouette_sheet.notes.md
04_[asset]_part_breakdown_sheet.notes.md
05_[asset]_color_palette_sheet.notes.md
06_[asset]_texture_reference_[atlas_size].notes.md
07_[asset]_closeup_detail_sheet.notes.md
08_[asset]_do_dont_sheet.notes.md
09_[asset]_animation_pivot_sheet_optional.notes.md
```

## Sheet Identity

- Image file:
- Sheet purpose:
- Current modelling phase supported:
- Priority:

## What Codex Should Read From This Image

- Main form:
- Front direction:
- Scale cues:
- Contact points:
- Important silhouette features:
- Important construction parts:
- Focal details:

## Geometry Interpretation

| Visual area | Geometry action | Texture-only action | Notes |
| --- | --- | --- | --- |
|  |  |  |  |

## Bounding / Placement Notes

| Part | Approx size | Position from root | Attachment | Rotation / pivot note |
| --- | --- | --- | --- | --- |
|  |  |  |  |  |

## Do Not Misinterpret

- Do not treat these texture details as cubes:
- Do not copy sample asset identity:
- Do not change front direction:
- Do not add floating parts unless explicitly marked:

## Pass / Fail Use

- Pass if:
- Fail if:
- Needs verification:

## Codex Instruction Summary

```text
Use this image to guide [phase]. Build/read only the listed geometry-level features. Treat all texture-only notes as later texture work.
```
