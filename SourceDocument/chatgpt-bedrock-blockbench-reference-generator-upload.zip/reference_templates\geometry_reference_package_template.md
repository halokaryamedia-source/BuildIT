# Geometri Referensi Package Template

## Tujuan
Template ini untuk membuat referensi yang konsisten agar fase geometri bisa dieksekusi dengan disiplin fase dan tidak amburadul antar-model.

## Struktur File (wajib)

Simpan di:
`SavedData/sessions/[asset]/references/`  
atau di `SourceDocument/reference-samples/[asset]/` untuk arsip final.

```text
01_[asset]_orthographic_views.png
02_[asset]_scale_sheet.png
03_[asset]_silhouette_sheet.png
04_[asset]_part_breakdown_sheet.png
05_[asset]_color_palette_sheet.png
06_[asset]_texture_reference_[atlas]x[atlas].png
07_[asset]_closeup_detail_sheet.png
08_[asset]_do_dont_sheet.png
09_[asset]_animation_pivot_sheet.png (optional)
reference_manifest.json
```

## Kontrak Konten per File

### 01_orthographic_views
- Wajib: frame dan jarak kamera konsisten.
- Sudut: front, side, back, 3/4, top.
- Pose: netral dan sama untuk semua sheet.
- Sertakan panah orientasi (front/back/left/right).

### 02_scale_sheet
- Tambah grid world + tinggi target (player-height).
- Cantumkan ukuran penting:
  - tinggi total
  - tinggi badan
  - panjang kaki
  - panjang ekor
  - radius/tinggi kepala
- Satuan tertulis jelas (px / unit / skin scale).

### 03_silhouette_sheet
- Siluet solid, high-contrast.
- Satu layer body, satu layer extremity, satu layer head/tail.
- Tidak ada tekstur. Hanya bentuk.

### 04_part_breakdown_sheet
- Tampilkan parent chain dan attachment point:
  - root, body, hip, shoulder, knee, ankle, limb_upper, limb_lower, paw, tail_base.
- Tandai joint pivot sebagai lingkaran kecil.
- Tulis urutan parent (contoh `tail_root -> tail_01 -> tail_02`).

### 05_color_palette_sheet
- 2 panel saja:
  1) Base material color swatches.
  2) Accent/shadow reference.
- Setiap swatch dengan hex dan nama area (badan, perut, kaki, telinga, hidung, mata).

### 06_texture_reference_[atlas]x[atlas]
- Versi tekstur referensi tetap konseptual, tanpa final UV.
- Sediakan juga preview UV-ready.

### 07_closeup_detail_sheet
- Fase: detail texture only.
- Isi area kritikal (mata, telinga, mulut, telapak, ekor ujung) tetapi label `Do not use in Main Geometry`.

### 08_do_dont_sheet
- Jangan campur geometri dan tekstur.
- 2 kolom:
  - Do: contoh bentuk tail chain benar, kaki-menempel, bahu stabil.
  - Don’t: contoh sendi terputus, kaki melayang, ekor bertingkat liar.

### 09_animation_pivot_sheet (optional)
- Prioritas geometri: pivot utama + arah rotasi.
- Harus mencantumkan:
  - axis x/y/z,
  - arah rotasi normal,
  - parent-child yang aman.

## Reference Manifest (wajib)

Isi `reference_manifest.json`:
- `asset_name`
- `asset`
- `phase_ready`
- `geometry_blueprint`
- `geometry_decision_notes`
- `negative_geometry_constraints`
- `view_consistency`
- `codex_first_action`
- `phases`
- `allowed_sources_by_phase`
- `stop_conditions`
- `accepted_assumptions`
- `blocking_questions`
- `needs_verification`
- `notes`

Contoh:

```json
{
  "asset_name": "kangaroo",
  "phase_ready": {
    "reference_collection": true,
    "main_geometry": true
  },
  "geometry_blueprint": {
    "global_envelope": {
      "height": "player-relative height",
      "width": "front width",
      "depth": "side depth",
      "front_direction": "front",
      "ground_contact_points": ["left_foot", "right_foot"]
    },
    "part_build_order": ["body", "head", "legs", "tail"],
    "part_bounding_boxes": []
  },
  "negative_geometry_constraints": ["fur marks", "small color bands", "tiny scratches"],
  "view_consistency": {
    "front_side_back_agree": "PASS",
    "scale_matches_orthographic": "PASS",
    "part_breakdown_matches_silhouette": "PASS"
  },
  "codex_first_action": "Run Reference Collection only. Do not edit Blockbench until Geometry Blueprint is accepted.",
  "phases": {
    "geometry": {
      "allowed_files": ["01", "02", "03", "04", "08", "09"],
      "ban_files": ["05", "06", "07"]
    }
  },
  "stop_conditions": {
    "geometry": ["front", "side", "back", "three_quarter"]
  },
  "accepted_assumptions": [],
  "notes": "Use fixed camera presets for all captures."
}
```

## Aturan Generate Ulang

1) Kumpulkan referensi mentah.
2) Buat orthographic + scale + silhouette dulu.
3) Finalisasi part breakdown + pivot.
4) Baru tambah warna/polish detail.
5) Jalankan pass/fail checklist sebelum Main Geometry.
