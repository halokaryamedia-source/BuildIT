/**
 * Internationalization (i18n) support for the MCP plugin.
 *
 * Uses Blockbench's built-in translation system:
 * - Language.addTranslations(langCode, { key: value }) to register translations
 * - tl('key') or tl('key', variables) to get translated strings
 *
 * Translation keys follow the pattern: mcp.<section>.<item>
 */

// English translations (fallback)
const en: Record<string, string> = {
  // Panel sections
  "mcp.panel.sessions": "Sessions",
  "mcp.panel.server": "Server",
  "mcp.panel.tools": "Tools",
  "mcp.panel.resources": "Resources",
  "mcp.panel.prompts": "Prompts",

  // Sessions section
  "mcp.sessions.no_clients": "No clients connected",

  // Server section
  "mcp.server.name": "Server Name",
  "mcp.server.version": "Server Version",
  "mcp.server.connected_clients": "Connected Clients",
  "mcp.server.status": "Status",
  "mcp.server.active_url": "Active URL",
  "mcp.server.requested_port": "Requested Port",
  "mcp.server.active_port": "Active Port",
  "mcp.server.endpoint": "Endpoint",
  "mcp.server.auto_port": "Auto-port",
  "mcp.server.fallback": "Fallback",
  "mcp.server.project": "Project",
  "mcp.server.copy_url": "Copy URL",
  "mcp.server.copy_codex": "Copy Codex TOML",
  "mcp.server.copy_cursor": "Copy Cursor JSON",
  "mcp.server.copy_vscode": "Copy VS Code JSON",
  "mcp.server.copy_claude": "Copy Claude Desktop JSON",
  "mcp.server.snippet_hint": "Each Blockbench window needs a unique mcpServers key.",
  "mcp.server.status_starting": "Starting",
  "mcp.server.status_listening": "Listening",
  "mcp.server.status_error": "Error",
  "mcp.server.status_stopped": "Stopped",
  "mcp.server.yes": "Yes",
  "mcp.server.no": "No",
  "mcp.server.copied": "Copied to clipboard",

  // Filter UI
  "mcp.filter.tools_placeholder": "Filter tools...",
  "mcp.filter.resources_placeholder": "Filter resources...",
  "mcp.filter.prompts_placeholder": "Filter prompts...",
  "mcp.filter.show_experimental": "Show Experimental",

  // Empty states
  "mcp.tools.no_match": "No tools match your filter.",
  "mcp.tools.none_available": "No tools available.",
  "mcp.resources.no_match": "No resources match your filter.",
  "mcp.resources.none_available": "No resources available.",
  "mcp.prompts.no_match": "No prompts match your filter.",
  "mcp.prompts.none_available": "No prompts available.",

  // Prompts
  "mcp.prompts.argument_count": "%0 argument",
  "mcp.prompts.argument_count_plural": "%0 arguments",

  // Tooltips
  "mcp.tooltip.click_to_test": "Click to test %0",
  "mcp.tooltip.click_to_preview": "Click to preview %0",
  "mcp.tooltip.click_to_view_panel": "Click to view MCP panel",

  // Status bar
  "mcp.status.experimental_tooltip": "This tool is experimental",
  "mcp.status.server": "MCP Server",
  "mcp.status.server_one_client": "MCP Server (1 client)",
  "mcp.status.server_clients": "MCP Server (%0 clients)",
  "mcp.status.server_error": "MCP Server Error",
  "mcp.status.fallback_tooltip": "Requested %0; using %1",

  // Settings
  "mcp.settings.instructions_name": "MCP System Instructions",
  "mcp.settings.instructions_desc": "Instructions for the MCP system.",
  "mcp.settings.port_name": "MCP Server Port",
  "mcp.settings.port_desc": "Port for the MCP server.",
  "mcp.settings.auto_port_name": "Auto-select Available Port",
  "mcp.settings.auto_port_desc": "If the configured MCP port is already in use, automatically try the next port. Useful when multiple Blockbench windows are open.",
  "mcp.settings.endpoint_name": "MCP Server Endpoint",
  "mcp.settings.endpoint_desc": "Endpoint for the MCP server.",
  "mcp.settings.prompt_cdn_name": "Enable Prompt CDN",
  "mcp.settings.prompt_cdn_desc": "Fetch prompt content from CDN on plugin load. Disable to use only cached prompts.",
  "mcp.settings.session_timeout_name": "Session Inactivity Timeout (minutes)",
  "mcp.settings.session_timeout_desc": "Disconnect MCP sessions after this many minutes of inactivity. Lower values free resources faster; higher values tolerate idle clients.",
  "mcp.settings.sse_heartbeat_name": "SSE Heartbeat Interval (seconds)",
  "mcp.settings.sse_heartbeat_desc": "Send keep-alive comments on streaming responses to prevent proxies/firewalls from closing idle connections. Set to 0 to disable.",

  // Tool test dialog
  "mcp.dialog.result_title": "Result: %0",
  "mcp.dialog.no_parameters": "This tool has no parameters.",
  "mcp.dialog.run_tool": "Run Tool",
  "mcp.dialog.copy_input": "Copy Input",
  "mcp.dialog.cancel": "Cancel",
  "mcp.dialog.close": "Close",
  "mcp.dialog.json_array_placeholder": "Enter JSON array, e.g. [1, 2, 3]",
  "mcp.dialog.json_object_placeholder": "Enter JSON object",
  "mcp.dialog.input_copied": "Input copied to clipboard",
  "mcp.dialog.copy_failed": "Failed to copy to clipboard",
  "mcp.dialog.running_tool": "Running tool...",
  "mcp.dialog.tool_not_found": "Tool \"%0\" not found",

  // Prompt preview dialog
  "mcp.dialog.prompt_title": "Prompt: %0",
  "mcp.dialog.copy": "Copy",
  "mcp.dialog.prompt_copied": "Prompt copied to clipboard",
  "mcp.dialog.no_arguments": "This prompt has no arguments.",
  "mcp.dialog.generate_prompt": "Generate Prompt",
  "mcp.dialog.generating_prompt": "Generating prompt...",
  "mcp.dialog.prompt_not_found": "Prompt \"%0\" not found",
  "mcp.dialog.role_user": "User",
  "mcp.dialog.role_assistant": "Assistant",

  // Prompt override dialog
  "mcp.dialog.edit_override": "Edit Override",
  "mcp.dialog.save_override": "Save Override",
  "mcp.dialog.reset_to_default": "Reset to Default",
  "mcp.dialog.override_saved": "Custom prompt override saved",
  "mcp.dialog.override_reset": "Prompt reset to default",
  "mcp.dialog.using_custom": "Using: Custom Override",
  "mcp.dialog.using_default": "Using: Default (v%0)",
  "mcp.prompts.custom_badge": "custom",
};

// German translations
const de: Record<string, string> = {
  // Panel sections
  "mcp.panel.sessions": "Sitzungen",
  "mcp.panel.server": "Server",
  "mcp.panel.tools": "Werkzeuge",
  "mcp.panel.resources": "Ressourcen",
  "mcp.panel.prompts": "Prompts",

  // Sessions section
  "mcp.sessions.no_clients": "Keine Clients verbunden",

  // Server section
  "mcp.server.name": "Servername",
  "mcp.server.version": "Serverversion",
  "mcp.server.connected_clients": "Verbundene Clients",
  "mcp.server.status": "Status",
  "mcp.server.active_url": "Aktive URL",
  "mcp.server.requested_port": "Angeforderter Port",
  "mcp.server.active_port": "Aktiver Port",
  "mcp.server.endpoint": "Endpunkt",
  "mcp.server.auto_port": "Auto-Port",
  "mcp.server.fallback": "Fallback",
  "mcp.server.project": "Projekt",
  "mcp.server.copy_url": "URL kopieren",
  "mcp.server.copy_codex": "Codex TOML kopieren",
  "mcp.server.copy_cursor": "Cursor JSON kopieren",
  "mcp.server.copy_vscode": "VS Code JSON kopieren",
  "mcp.server.copy_claude": "Claude Desktop JSON kopieren",
  "mcp.server.snippet_hint": "Jedes Blockbench-Fenster benötigt einen eindeutigen mcpServers-Schlüssel.",
  "mcp.server.status_starting": "Startet",
  "mcp.server.status_listening": "Lauscht",
  "mcp.server.status_error": "Fehler",
  "mcp.server.status_stopped": "Gestoppt",
  "mcp.server.yes": "Ja",
  "mcp.server.no": "Nein",
  "mcp.server.copied": "In Zwischenablage kopiert",

  // Filter UI
  "mcp.filter.tools_placeholder": "Werkzeuge filtern...",
  "mcp.filter.resources_placeholder": "Ressourcen filtern...",
  "mcp.filter.prompts_placeholder": "Prompts filtern...",
  "mcp.filter.show_experimental": "Experimentelle anzeigen",

  // Empty states
  "mcp.tools.no_match": "Keine Werkzeuge entsprechen Ihrem Filter.",
  "mcp.tools.none_available": "Keine Werkzeuge verfügbar.",
  "mcp.resources.no_match": "Keine Ressourcen entsprechen Ihrem Filter.",
  "mcp.resources.none_available": "Keine Ressourcen verfügbar.",
  "mcp.prompts.no_match": "Keine Prompts entsprechen Ihrem Filter.",
  "mcp.prompts.none_available": "Keine Prompts verfügbar.",

  // Prompts
  "mcp.prompts.argument_count": "%0 Argument",
  "mcp.prompts.argument_count_plural": "%0 Argumente",

  // Tooltips
  "mcp.tooltip.click_to_test": "Klicken zum Testen von %0",
  "mcp.tooltip.click_to_preview": "Klicken zur Vorschau von %0",
  "mcp.tooltip.click_to_view_panel": "Klicken zum Anzeigen des MCP-Panels",

  // Status bar
  "mcp.status.experimental_tooltip": "Dieses Werkzeug ist experimentell",
  "mcp.status.server": "MCP Server",
  "mcp.status.server_one_client": "MCP Server (1 Client)",
  "mcp.status.server_clients": "MCP Server (%0 Clients)",
  "mcp.status.server_error": "MCP Server Fehler",
  "mcp.status.fallback_tooltip": "Angefordert %0; verwendet %1",

  // Settings
  "mcp.settings.instructions_name": "MCP Systemanweisungen",
  "mcp.settings.instructions_desc": "Anweisungen für das MCP-System.",
  "mcp.settings.port_name": "MCP Server Port",
  "mcp.settings.port_desc": "Port für den MCP-Server.",
  "mcp.settings.auto_port_name": "Verfügbaren Port automatisch wählen",
  "mcp.settings.auto_port_desc": "Wenn der konfigurierte MCP-Port bereits belegt ist, automatisch den nächsten Port versuchen. Nützlich bei mehreren Blockbench-Fenstern.",
  "mcp.settings.endpoint_name": "MCP Server Endpunkt",
  "mcp.settings.endpoint_desc": "Endpunkt für den MCP-Server.",
  "mcp.settings.prompt_cdn_name": "Prompt-CDN aktivieren",
  "mcp.settings.prompt_cdn_desc": "Prompt-Inhalte beim Laden des Plugins vom CDN abrufen. Deaktivieren, um nur zwischengespeicherte Prompts zu verwenden.",
  "mcp.settings.session_timeout_name": "Sitzungs-Inaktivitäts-Timeout (Minuten)",
  "mcp.settings.session_timeout_desc": "MCP-Sitzungen nach dieser Anzahl von Minuten Inaktivität trennen. Niedrigere Werte geben Ressourcen schneller frei; höhere Werte tolerieren inaktive Clients.",
  "mcp.settings.sse_heartbeat_name": "SSE-Heartbeat-Intervall (Sekunden)",
  "mcp.settings.sse_heartbeat_desc": "Sendet Keep-Alive-Kommentare auf Streaming-Antworten, um zu verhindern, dass Proxys/Firewalls inaktive Verbindungen schließen. Auf 0 setzen zum Deaktivieren.",

  // Tool test dialog
  "mcp.dialog.result_title": "Ergebnis: %0",
  "mcp.dialog.no_parameters": "Dieses Werkzeug hat keine Parameter.",
  "mcp.dialog.run_tool": "Werkzeug ausführen",
  "mcp.dialog.copy_input": "Eingabe kopieren",
  "mcp.dialog.cancel": "Abbrechen",
  "mcp.dialog.close": "Schließen",
  "mcp.dialog.json_array_placeholder": "JSON-Array eingeben, z.B. [1, 2, 3]",
  "mcp.dialog.json_object_placeholder": "JSON-Objekt eingeben",
  "mcp.dialog.input_copied": "Eingabe in Zwischenablage kopiert",
  "mcp.dialog.copy_failed": "Kopieren in Zwischenablage fehlgeschlagen",
  "mcp.dialog.running_tool": "Werkzeug wird ausgeführt...",
  "mcp.dialog.tool_not_found": "Werkzeug \"%0\" nicht gefunden",

  // Prompt preview dialog
  "mcp.dialog.prompt_title": "Prompt: %0",
  "mcp.dialog.copy": "Kopieren",
  "mcp.dialog.prompt_copied": "Prompt in Zwischenablage kopiert",
  "mcp.dialog.no_arguments": "Dieser Prompt hat keine Argumente.",
  "mcp.dialog.generate_prompt": "Prompt generieren",
  "mcp.dialog.generating_prompt": "Prompt wird generiert...",
  "mcp.dialog.prompt_not_found": "Prompt \"%0\" nicht gefunden",
  "mcp.dialog.role_user": "Benutzer",
  "mcp.dialog.role_assistant": "Assistent",

  // Prompt override dialog
  "mcp.dialog.edit_override": "Override bearbeiten",
  "mcp.dialog.save_override": "Override speichern",
  "mcp.dialog.reset_to_default": "Auf Standard zurücksetzen",
  "mcp.dialog.override_saved": "Benutzerdefiniertes Prompt-Override gespeichert",
  "mcp.dialog.override_reset": "Prompt auf Standard zurückgesetzt",
  "mcp.dialog.using_custom": "Verwendet: Benutzerdefiniert",
  "mcp.dialog.using_default": "Verwendet: Standard (v%0)",
  "mcp.prompts.custom_badge": "custom",
};

// Japanese translations
const ja: Record<string, string> = {
  // Panel sections
  "mcp.panel.sessions": "セッション",
  "mcp.panel.server": "サーバー",
  "mcp.panel.tools": "ツール",
  "mcp.panel.resources": "リソース",
  "mcp.panel.prompts": "プロンプト",

  // Sessions section
  "mcp.sessions.no_clients": "クライアントが接続されていません",

  // Server section
  "mcp.server.name": "サーバー名",
  "mcp.server.version": "サーバーバージョン",
  "mcp.server.connected_clients": "接続中のクライアント",
  "mcp.server.status": "ステータス",
  "mcp.server.active_url": "アクティブURL",
  "mcp.server.requested_port": "要求ポート",
  "mcp.server.active_port": "アクティブポート",
  "mcp.server.endpoint": "エンドポイント",
  "mcp.server.auto_port": "自動ポート",
  "mcp.server.fallback": "フォールバック",
  "mcp.server.project": "プロジェクト",
  "mcp.server.copy_url": "URLをコピー",
  "mcp.server.copy_codex": "Codex TOMLをコピー",
  "mcp.server.copy_cursor": "Cursor JSONをコピー",
  "mcp.server.copy_vscode": "VS Code JSONをコピー",
  "mcp.server.copy_claude": "Claude Desktop JSONをコピー",
  "mcp.server.snippet_hint": "各Blockbenchウィンドウには一意のmcpServersキーが必要です。",
  "mcp.server.status_starting": "起動中",
  "mcp.server.status_listening": "待受中",
  "mcp.server.status_error": "エラー",
  "mcp.server.status_stopped": "停止",
  "mcp.server.yes": "はい",
  "mcp.server.no": "いいえ",
  "mcp.server.copied": "クリップボードにコピーしました",

  // Filter UI
  "mcp.filter.tools_placeholder": "ツールを検索...",
  "mcp.filter.resources_placeholder": "リソースを検索...",
  "mcp.filter.prompts_placeholder": "プロンプトを検索...",
  "mcp.filter.show_experimental": "実験的を表示",

  // Empty states
  "mcp.tools.no_match": "フィルターに一致するツールがありません。",
  "mcp.tools.none_available": "利用可能なツールがありません。",
  "mcp.resources.no_match": "フィルターに一致するリソースがありません。",
  "mcp.resources.none_available": "利用可能なリソースがありません。",
  "mcp.prompts.no_match": "フィルターに一致するプロンプトがありません。",
  "mcp.prompts.none_available": "利用可能なプロンプトがありません。",

  // Prompts
  "mcp.prompts.argument_count": "%0 引数",
  "mcp.prompts.argument_count_plural": "%0 引数",

  // Tooltips
  "mcp.tooltip.click_to_test": "クリックして %0 をテスト",
  "mcp.tooltip.click_to_preview": "クリックして %0 をプレビュー",
  "mcp.tooltip.click_to_view_panel": "クリックしてMCPパネルを表示",

  // Status bar
  "mcp.status.experimental_tooltip": "このツールは実験的です",
  "mcp.status.server": "MCPサーバー",
  "mcp.status.server_one_client": "MCPサーバー (1クライアント)",
  "mcp.status.server_clients": "MCPサーバー (%0クライアント)",
  "mcp.status.server_error": "MCPサーバーエラー",
  "mcp.status.fallback_tooltip": "要求 %0; 使用中 %1",

  // Settings
  "mcp.settings.instructions_name": "MCPシステム指示",
  "mcp.settings.instructions_desc": "MCPシステムの指示。",
  "mcp.settings.port_name": "MCPサーバーポート",
  "mcp.settings.port_desc": "MCPサーバーのポート。",
  "mcp.settings.auto_port_name": "利用可能なポートを自動選択",
  "mcp.settings.auto_port_desc": "設定したMCPポートが使用中の場合、次のポートを自動的に試します。複数のBlockbenchウィンドウを開く場合に便利です。",
  "mcp.settings.endpoint_name": "MCPサーバーエンドポイント",
  "mcp.settings.endpoint_desc": "MCPサーバーのエンドポイント。",
  "mcp.settings.prompt_cdn_name": "プロンプトCDNを有効化",
  "mcp.settings.prompt_cdn_desc": "プラグイン読み込み時にCDNからプロンプト内容を取得します。無効にするとキャッシュされたプロンプトのみ使用します。",
  "mcp.settings.session_timeout_name": "セッション非アクティブタイムアウト (分)",
  "mcp.settings.session_timeout_desc": "この分数の非アクティブ後にMCPセッションを切断します。値が小さいほどリソースを早く解放し、大きいほどアイドルクライアントを許容します。",
  "mcp.settings.sse_heartbeat_name": "SSEハートビート間隔 (秒)",
  "mcp.settings.sse_heartbeat_desc": "ストリーミング応答にキープアライブコメントを送信し、プロキシ/ファイアウォールがアイドル接続を閉じるのを防ぎます。0に設定すると無効になります。",

  // Tool test dialog
  "mcp.dialog.result_title": "結果: %0",
  "mcp.dialog.no_parameters": "このツールにはパラメータがありません。",
  "mcp.dialog.run_tool": "ツールを実行",
  "mcp.dialog.copy_input": "入力をコピー",
  "mcp.dialog.cancel": "キャンセル",
  "mcp.dialog.close": "閉じる",
  "mcp.dialog.json_array_placeholder": "JSON配列を入力 (例: [1, 2, 3])",
  "mcp.dialog.json_object_placeholder": "JSONオブジェクトを入力",
  "mcp.dialog.input_copied": "入力をクリップボードにコピーしました",
  "mcp.dialog.copy_failed": "クリップボードへのコピーに失敗しました",
  "mcp.dialog.running_tool": "ツールを実行中...",
  "mcp.dialog.tool_not_found": "ツール \"%0\" が見つかりません",

  // Prompt preview dialog
  "mcp.dialog.prompt_title": "プロンプト: %0",
  "mcp.dialog.copy": "コピー",
  "mcp.dialog.prompt_copied": "プロンプトをクリップボードにコピーしました",
  "mcp.dialog.no_arguments": "このプロンプトには引数がありません。",
  "mcp.dialog.generate_prompt": "プロンプトを生成",
  "mcp.dialog.generating_prompt": "プロンプトを生成中...",
  "mcp.dialog.prompt_not_found": "プロンプト \"%0\" が見つかりません",
  "mcp.dialog.role_user": "ユーザー",
  "mcp.dialog.role_assistant": "アシスタント",

  // Prompt override dialog
  "mcp.dialog.edit_override": "オーバーライドを編集",
  "mcp.dialog.save_override": "オーバーライドを保存",
  "mcp.dialog.reset_to_default": "デフォルトに戻す",
  "mcp.dialog.override_saved": "カスタムプロンプトオーバーライドを保存しました",
  "mcp.dialog.override_reset": "プロンプトをデフォルトに戻しました",
  "mcp.dialog.using_custom": "使用中: カスタム",
  "mcp.dialog.using_default": "使用中: デフォルト (v%0)",
  "mcp.prompts.custom_badge": "カスタム",
};

// Chinese (Simplified) translations
const zh: Record<string, string> = {
  // Panel sections
  "mcp.panel.sessions": "会话",
  "mcp.panel.server": "服务器",
  "mcp.panel.tools": "工具",
  "mcp.panel.resources": "资源",
  "mcp.panel.prompts": "提示词",

  // Sessions section
  "mcp.sessions.no_clients": "没有客户端连接",

  // Server section
  "mcp.server.name": "服务器名称",
  "mcp.server.version": "服务器版本",
  "mcp.server.connected_clients": "已连接客户端",
  "mcp.server.status": "状态",
  "mcp.server.active_url": "活动URL",
  "mcp.server.requested_port": "请求端口",
  "mcp.server.active_port": "活动端口",
  "mcp.server.endpoint": "端点",
  "mcp.server.auto_port": "自动端口",
  "mcp.server.fallback": "回退",
  "mcp.server.project": "项目",
  "mcp.server.copy_url": "复制URL",
  "mcp.server.copy_codex": "复制Codex TOML",
  "mcp.server.copy_cursor": "复制Cursor JSON",
  "mcp.server.copy_vscode": "复制VS Code JSON",
  "mcp.server.copy_claude": "复制Claude Desktop JSON",
  "mcp.server.snippet_hint": "每个Blockbench窗口需要唯一的mcpServers键。",
  "mcp.server.status_starting": "启动中",
  "mcp.server.status_listening": "监听中",
  "mcp.server.status_error": "错误",
  "mcp.server.status_stopped": "已停止",
  "mcp.server.yes": "是",
  "mcp.server.no": "否",
  "mcp.server.copied": "已复制到剪贴板",

  // Filter UI
  "mcp.filter.tools_placeholder": "筛选工具...",
  "mcp.filter.resources_placeholder": "筛选资源...",
  "mcp.filter.prompts_placeholder": "筛选提示词...",
  "mcp.filter.show_experimental": "显示实验性",

  // Empty states
  "mcp.tools.no_match": "没有匹配的工具。",
  "mcp.tools.none_available": "没有可用的工具。",
  "mcp.resources.no_match": "没有匹配的资源。",
  "mcp.resources.none_available": "没有可用的资源。",
  "mcp.prompts.no_match": "没有匹配的提示词。",
  "mcp.prompts.none_available": "没有可用的提示词。",

  // Prompts
  "mcp.prompts.argument_count": "%0 个参数",
  "mcp.prompts.argument_count_plural": "%0 个参数",

  // Tooltips
  "mcp.tooltip.click_to_test": "点击测试 %0",
  "mcp.tooltip.click_to_preview": "点击预览 %0",
  "mcp.tooltip.click_to_view_panel": "点击查看MCP面板",

  // Status bar
  "mcp.status.experimental_tooltip": "此工具为实验性功能",
  "mcp.status.server": "MCP服务器",
  "mcp.status.server_one_client": "MCP服务器 (1个客户端)",
  "mcp.status.server_clients": "MCP服务器 (%0个客户端)",
  "mcp.status.server_error": "MCP服务器错误",
  "mcp.status.fallback_tooltip": "请求 %0; 使用 %1",

  // Settings
  "mcp.settings.instructions_name": "MCP系统指令",
  "mcp.settings.instructions_desc": "MCP系统的指令。",
  "mcp.settings.port_name": "MCP服务器端口",
  "mcp.settings.port_desc": "MCP服务器的端口。",
  "mcp.settings.auto_port_name": "自动选择可用端口",
  "mcp.settings.auto_port_desc": "如果配置的MCP端口已被占用，自动尝试下一个端口。适用于同时打开多个Blockbench窗口。",
  "mcp.settings.endpoint_name": "MCP服务器端点",
  "mcp.settings.endpoint_desc": "MCP服务器的端点。",
  "mcp.settings.prompt_cdn_name": "启用提示词CDN",
  "mcp.settings.prompt_cdn_desc": "插件加载时从CDN获取提示词内容。禁用后仅使用缓存的提示词。",
  "mcp.settings.session_timeout_name": "会话非活动超时（分钟）",
  "mcp.settings.session_timeout_desc": "在非活动指定分钟数后断开 MCP 会话。较低的值更快释放资源；较高的值容忍空闲客户端。",
  "mcp.settings.sse_heartbeat_name": "SSE 心跳间隔（秒）",
  "mcp.settings.sse_heartbeat_desc": "在流式响应上发送保活注释，防止代理/防火墙关闭空闲连接。设为 0 表示禁用。",

  // Tool test dialog
  "mcp.dialog.result_title": "结果: %0",
  "mcp.dialog.no_parameters": "此工具没有参数。",
  "mcp.dialog.run_tool": "运行工具",
  "mcp.dialog.copy_input": "复制输入",
  "mcp.dialog.cancel": "取消",
  "mcp.dialog.close": "关闭",
  "mcp.dialog.json_array_placeholder": "输入JSON数组，例如 [1, 2, 3]",
  "mcp.dialog.json_object_placeholder": "输入JSON对象",
  "mcp.dialog.input_copied": "输入已复制到剪贴板",
  "mcp.dialog.copy_failed": "复制到剪贴板失败",
  "mcp.dialog.running_tool": "正在运行工具...",
  "mcp.dialog.tool_not_found": "未找到工具 \"%0\"",

  // Prompt preview dialog
  "mcp.dialog.prompt_title": "提示词: %0",
  "mcp.dialog.copy": "复制",
  "mcp.dialog.prompt_copied": "提示词已复制到剪贴板",
  "mcp.dialog.no_arguments": "此提示词没有参数。",
  "mcp.dialog.generate_prompt": "生成提示词",
  "mcp.dialog.generating_prompt": "正在生成提示词...",
  "mcp.dialog.prompt_not_found": "未找到提示词 \"%0\"",
  "mcp.dialog.role_user": "用户",
  "mcp.dialog.role_assistant": "助手",

  // Prompt override dialog
  "mcp.dialog.edit_override": "编辑覆盖",
  "mcp.dialog.save_override": "保存覆盖",
  "mcp.dialog.reset_to_default": "重置为默认",
  "mcp.dialog.override_saved": "自定义提示词覆盖已保存",
  "mcp.dialog.override_reset": "提示词已重置为默认",
  "mcp.dialog.using_custom": "使用中: 自定义",
  "mcp.dialog.using_default": "使用中: 默认 (v%0)",
  "mcp.prompts.custom_badge": "自定义",
};

// All translations mapped by language code
const translations: Record<string, Record<string, string>> = {
  en,
  de,
  ja,
  zh,
};

/**
 * Registers all MCP plugin translations with Blockbench's language system.
 * Should be called during plugin setup.
 */
export function setupI18n(): void {
  // Always register English first as the fallback
  Language.addTranslations("en", en);

  // Register other languages
  for (const [langCode, strings] of Object.entries(translations)) {
    if (langCode !== "en") {
      Language.addTranslations(langCode, strings);
    }
  }
}

/**
 * Helper to format argument count with proper pluralization
 */
export function formatArgumentCount(count: number): string {
  if (count === 1) {
    return tl("mcp.prompts.argument_count", [count]);
  }
  return tl("mcp.prompts.argument_count_plural", [count]);
}
