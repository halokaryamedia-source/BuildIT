export type BlockbenchSessionAuth = undefined;
