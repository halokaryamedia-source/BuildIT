# MCP-Blockbench Reference Studio — GitHub Live

This is the installation source for a **ChatGPT Skill**.

Upload the ZIP to ChatGPT. The installed bootstrap loads the current Reference
Studio and production-stage rules from BuildIT branch `Rework`.

GitHub remains the source of truth. Ordinary rule and template updates in the
repository do not require replacing the bootstrap ZIP.

Run `SYNC STATUS` in ChatGPT to verify the resolved commit and loaded files.
