# GitHub Live Sync Rules

## Primary authority

```text
repository: halokaryamedia-source/BuildIT
branch: Rework
canonical ChatGPT skill root:
engines/chatgpt/skills/blockbench-reference-studio
```

This bootstrap contains routing instructions, not a replacement copy of the
full workflow. Current workflow data must be read from GitHub.

## Sync moments

Sync at task start and before:

```text
PACKAGE
HANDOFF
VALIDATE PACKAGE
PREPARE LOCAL TEST
```

Also sync after `SYNC`, `SYNC SKILL`, `REFRESH`, or when the user reports a
repository update. Do not repeatedly sync during one unchanged phase.

## Authority order

```text
current user instruction
→ current GitHub Rework authority
→ approved candidate decisions
→ safe defaults
```

## Compatibility

Verify that the remote Reference Studio uses contract 3.3 or a compatible
successor and that all five shared production-stage skills exist.

A branch name alone is not a version record. Resolve the commit SHA where the
available GitHub tool supports it. Otherwise record exact file hashes and state
that branch-head resolution was unavailable.

## No silent offline fallback

If GitHub cannot be read, report the sync blocker. This bootstrap does not
claim that an embedded copy is the latest workflow.
