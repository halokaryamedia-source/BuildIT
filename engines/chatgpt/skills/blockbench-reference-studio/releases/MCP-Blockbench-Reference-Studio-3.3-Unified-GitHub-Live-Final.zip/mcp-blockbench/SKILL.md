---
name: blockbench-reference-studio
description: "GitHub-live bootstrap for the Minecraft Bedrock / Blockbench Reference Studio. Loads current Reference Studio, Geometry, Texture, Animation, Validation, and Codex handoff rules from BuildIT branch Rework."
---

# Blockbench Reference Studio — GitHub Live Bootstrap

This ZIP is installed as a **ChatGPT Skill**. GitHub branch `Rework` is the
live source of truth for workflow data.

## Required startup sync

At the beginning of every compatible task, resolve and read:

```text
repository: halokaryamedia-source/BuildIT
branch: Rework
canonical root: engines/chatgpt/skills/blockbench-reference-studio
```

Load these core files:

```text
engines/chatgpt/skills/blockbench-reference-studio/SKILL.md
engines/shared/skills/blockbench-production/SKILL.md
engines/shared/skills/blockbench-geometry/SKILL.md
engines/shared/skills/blockbench-texture/SKILL.md
engines/shared/skills/blockbench-animation/SKILL.md
engines/shared/skills/blockbench-validation/SKILL.md
```

Then load only phase-relevant `references/`, `templates/`, and Golden Sample
files from the canonical Reference Studio root.

## Authority record

Record the repository, branch, resolved Rework commit SHA when available,
loaded file paths, blob SHA or content hash, sync timestamp, and all missing or
incompatible files.

Never claim `latest`, `synced`, or `using Rework` unless GitHub was fetched.

## Commands

```text
SYNC
SYNC SKILL
SYNC STATUS
REFRESH
```

`SYNC STATUS` reports the resolved commit, loaded files, hashes, and blockers.

## Failure behavior

Fail closed instead of silently using stale rules:

```text
GITHUB_SKILL_SYNC_UNAVAILABLE
GITHUB_SKILL_AUTHORITY_MISSING
GITHUB_SKILL_FILE_EMPTY
GITHUB_SKILL_VERSION_INCOMPATIBLE
GITHUB_SKILL_AUTHORITY_CONFLICT
GITHUB_SKILL_HASH_MISMATCH
GITHUB_SKILL_BRANCH_UNRESOLVED
```

## Workflow boundary

ChatGPT creates and validates the Reference Candidate. Codex and
MCP-Blockbench begin only after the package is complete. Do not edit a
`.bbmodel`, acquire a lease, or claim a local Blockbench result from ChatGPT.

The active candidate remains authoritative for approved asset identity,
dimensions, visible design, Reference Visual hash, Geometry, Texture, and
Animation decisions. Live rules must not silently redesign it.

Before producing a Codex/local-test prompt, sync GitHub once more and instruct
Codex to independently resolve the latest `origin/Rework`.
